package com.zhongyou.meet.mobile.event;

/**用户数据更新,进主页要用token刷新用户信息
 * Created by wufan on 2017/8/10.
 */

public class UserUpdateEvent {
}
