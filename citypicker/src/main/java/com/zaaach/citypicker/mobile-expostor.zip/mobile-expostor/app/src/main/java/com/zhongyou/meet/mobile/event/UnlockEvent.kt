package com.zhongyou.meet.mobile.event

class UnlockEvent(var isLock:Boolean)