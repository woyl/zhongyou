package com.zhongyou.meet.mobile.entities;

/**
 * Created by wufan on 2017/8/1.
 */

public class RecordTotal {

    /**
     * total : 0
     */

    private int total;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
