package com.zhongyou.meet.mobile.event;

/**超过30秒,用户挂断电话
 * Created by wufan on 2017/8/5.
 */

public class TvTimeoutHangUp {
}
