package com.zhongyou.meet.mobile.mvp.presenter;

import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bumptech.glide.Glide;
import com.jess.arms.di.scope.ActivityScope;
import com.jess.arms.http.imageloader.ImageLoader;
import com.jess.arms.integration.AppManager;
import com.jess.arms.mvp.BasePresenter;
import com.jess.arms.utils.RxLifecycleUtils;
import com.xw.repo.BubbleSeekBar;
import com.zhongyou.meet.mobile.R;
import com.zhongyou.meet.mobile.ameeting.adater.BaseRecyclerHolder;
import com.zhongyou.meet.mobile.ameeting.adater.BaseRecyclerViewAdapter;
import com.zhongyou.meet.mobile.ameeting.network.RxSchedulersHelper;
import com.zhongyou.meet.mobile.ameeting.network.RxSubscriber;
import com.zhongyou.meet.mobile.core.CommonUtils;
import com.zhongyou.meet.mobile.core.GlobalConsts;
import com.zhongyou.meet.mobile.core.PlayService;
import com.zhongyou.meet.mobile.entiy.MoreAudio;
import com.zhongyou.meet.mobile.mvp.contract.MakerCourseAudioContract;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.disposables.Disposable;
import me.jessyan.rxerrorhandler.core.RxErrorHandler;
import timber.log.Timber;


/**
 * ================================================
 * Description:
 * <p>
 * Created by MVPArmsTemplate on 04/08/2020 13:43
 * <a href="mailto:jess.yan.effort@gmail.com">Contact me</a>
 * <a href="https://github.com/JessYanCoding">Follow me</a>
 * <a href="https://github.com/JessYanCoding/MVPArms">Star me</a>
 * <a href="https://github.com/JessYanCoding/MVPArms/wiki">See me</a>
 * <a href="https://github.com/JessYanCoding/MVPArmsTemplate">模版请保持更新</a>
 * ================================================
 */
@ActivityScope
public class MakerCourseAudioPresenter extends BasePresenter<MakerCourseAudioContract.Model, MakerCourseAudioContract.View> {
	@Inject
	RxErrorHandler mErrorHandler;
	@Inject
	Application mApplication;
	@Inject
	ImageLoader mImageLoader;
	@Inject
	AppManager mAppManager;
	private int clickPosition = -1;
	private MusicInfoReceiver receiver;
	private ServiceConnection serviceConn;
	private static PlayService.MusicBinder musicBinder;
	List<MoreAudio> moreAudios = new ArrayList<>();

	@Inject
	public MakerCourseAudioPresenter(MakerCourseAudioContract.Model model, MakerCourseAudioContract.View rootView) {
		super(model, rootView);
	}


	public int getCurrentPosition() {
		return clickPosition;
	}

	public BaseRecyclerViewAdapter<MoreAudio> initAudioRecyclerAdapter(PlayService.MusicBinder musicBinder1, final Animation mOperatingAnim) {


		return new BaseRecyclerViewAdapter<MoreAudio>(mApplication, mRootView.getData(), R.layout.item_maker_course_audio_more) {

			@Override
			public void convert(BaseRecyclerHolder holder, MoreAudio item, int position, boolean isScrolling) {

				holder.getView(R.id.timeLayout).setVisibility(View.GONE);
				if (position == 0) {
					Timber.e("1111  "+position+"   item.getDate()---->%s ---%s", item.getDate(), item.getName());
					holder.getView(R.id.timeLayout).setVisibility(View.VISIBLE);
					holder.setText(R.id.recommendDate, item.getDate());
					holder.getView(R.id.view_Line).setVisibility(View.VISIBLE);
					View recommendAudio = holder.getView(R.id.recommendAudio);
					if (recommendAudio != null) {
						recommendAudio.setVisibility(View.VISIBLE);
					}
				}

				if (position - 1 > 0) {
					if (item.getDate().equals(mRootView.getData().get(position - 1).getDate())) {
						holder.getView(R.id.view_Line).setVisibility(View.GONE);
						holder.getView(R.id.timeLayout).setVisibility(View.GONE);
						View recommendAudio = holder.getView(R.id.recommendAudio);
						if (recommendAudio != null) {
							recommendAudio.setVisibility(View.VISIBLE);
						}
					} else {
						Timber.e("22222  "+position+"  item.getDate()---->%s ---%s", item.getDate(), item.getName());
						holder.getView(R.id.timeLayout).setVisibility(View.VISIBLE);
						holder.setText(R.id.recommendDate, item.getDate());
						holder.getView(R.id.view_Line).setVisibility(View.VISIBLE);
						View recommendAudio = holder.getView(R.id.recommendAudio);
						if (recommendAudio != null) {
							recommendAudio.setVisibility(View.VISIBLE);
						}
					}

				}


				BubbleSeekBar seekBar = holder.getView(R.id.seekBar);
				seekBar.getConfigBuilder().max(item.getTotalTime()).progress((int) item.getCurrentDuration()).build();
				if (item.getType() == 0) {
					seekBar.setVisibility(View.GONE);
				} else if (seekBar.getVisibility() != View.VISIBLE) {
					seekBar.setVisibility(View.VISIBLE);
				}

				if (position == mRootView.getData().size() - 1) {
					holder.getView(R.id.line).setVisibility(View.GONE);
				}

				if (item.isExpanded()) {
					if (holder.getView(R.id.descriptionImage).getVisibility() != View.VISIBLE) {
						holder.getView(R.id.descriptionImage).setVisibility(View.VISIBLE);
						Glide.with(mApplication).load(item.getComentURL()).skipMemoryCache(false).into((ImageView) holder.getView(R.id.descriptionImage));
					}
				} else {
					if (holder.getView(R.id.descriptionImage).getVisibility() != View.GONE) {
						holder.getView(R.id.descriptionImage).setVisibility(View.GONE);
					}
				}

				holder.itemView.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if (null == item.getVioceURL()) {
							return;
						}
						if (clickPosition == -1) {
							playMusic(mRootView.getData(), position, item.getVioceURL(), 3);
						} else {
							if (position == clickPosition) {
								if (mRootView.getData().get(position).getType() == 0) {
									playMusic(mRootView.getData(), position, item.getVioceURL(), 3);
								} else if (mRootView.getData().get(position).getType() == 1) {
									musicBinder.pause();
									mRootView.getData().get(position).setType(2);
								} else if (mRootView.getData().get(position).getType() == 2) {
									musicBinder.start();
									mRootView.getData().get(position).setType(1);
								}
							} else {
								mRootView.getData().get(clickPosition).setType(0);
								mRootView.getData().get(clickPosition).setCurrentDuration(0);
								playMusic(mRootView.getData(), position, item.getVioceURL(), 3);

							}

						}

						if (item.getType() != 1 && item.getType() != 3) {
							item.setExpanded(false);
							holder.getView(R.id.descriptionImage).setVisibility(View.GONE);
						} else {
							item.setExpanded(true);
							holder.getView(R.id.descriptionImage).setVisibility(View.VISIBLE);
						}

						notifyDataSetChanged();
					}
				});
				if (mRootView.getData().get(position).getType() == 1) {
					holder.setImageResource(R.id.audioState, R.drawable.icon_audio_pause);
				} else if (mRootView.getData().get(position).getType() == 3) {
					holder.setImageResource(R.id.audioState, R.drawable.icon_audio_loading);

//					mOperatingAnim = AnimationUtils.loadAnimation(mApplication, R.anim.tip);
					LinearInterpolator lin = new LinearInterpolator();
					mOperatingAnim.setInterpolator(lin);
					holder.getView(R.id.audioState).startAnimation(mOperatingAnim);

				} else {
					holder.setImageResource(R.id.audioState, R.drawable.audio);
				}

				holder.setText(R.id.className, item.getName());

				holder.setText(R.id.teacherName, "主讲人:" + item.getAnchorName());

				holder.setText(R.id.classDate, item.getBelongTime());

				holder.setText(R.id.classTime, CommonUtils.getFormattedTime(item.getCurrentDuration()) + "/" + item.getTotalDate());

				holder.getView(R.id.audioState).setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if (null == item.getVioceURL()) {
							return;
						}
						if (clickPosition == -1) {
							playMusic(mRootView.getData(), position, item.getVioceURL(), 3);
						} else {
							if (position == clickPosition) {
								if (mRootView.getData().get(position).getType() == 0) {
									playMusic(mRootView.getData(), position, item.getVioceURL(), 3);
								} else if (mRootView.getData().get(position).getType() == 1) {
									musicBinder.pause();
									mRootView.getData().get(position).setType(2);
								} else if (mRootView.getData().get(position).getType() == 2) {
									musicBinder.start();
									mRootView.getData().get(position).setType(1);
								}
							} else {
								mRootView.getData().get(clickPosition).setType(0);
								mRootView.getData().get(clickPosition).setCurrentDuration(0);
								playMusic(mRootView.getData(), position, item.getVioceURL(), 3);

							}

						}

						if (item.getType() != 1 && item.getType() != 3) {
							item.setExpanded(false);
							holder.getView(R.id.descriptionImage).setVisibility(View.GONE);
						} else {
							item.setExpanded(true);
							holder.getView(R.id.descriptionImage).setVisibility(View.VISIBLE);
						}

						notifyDataSetChanged();

					}
				});
			}
		};
	}

	public void playMusic(List<MoreAudio> musicData, int position, String url, int type) {
		musicData.get(position).setType(type);
		musicBinder.playMusic(url);
		if (clickPosition != -1) {
			musicData.get(clickPosition).setExpanded(false);
		}
		clickPosition = position;

	}

	public void getMoreAudio(int page) {
		if (mModel != null) {
			mModel.getMoreAudio(page).compose(RxLifecycleUtils.bindToLifecycle(mRootView))
					.compose(RxSchedulersHelper.io_main())
					.subscribe(new RxSubscriber<JSONObject>() {
						@Override
						public void onSubscribe(Disposable d) {
							addDispose(d);
						}

						@Override
						public void _onNext(JSONObject jsonObject) {
							if (jsonObject.getInteger("errcode") == 0) {

								if (page == 1) {
									moreAudios.clear();
								}
								JSONObject json = jsonObject.getJSONObject("data");
								if (json.containsKey("changeLessonByDayList")) {
									int totalPage = json.getJSONObject("changeLessonByDayList").getInteger("totalPage");
									mRootView.setTotalPage(totalPage);
									JSONArray data = json.getJSONObject("changeLessonByDayList").getJSONArray("list");

									for (int i = 0; i < data.size(); i++) {
										List<MoreAudio> list = JSONArray.parseArray(data.getJSONObject(i).getJSONArray("list").toJSONString(), MoreAudio.class);
										for (MoreAudio moreAudio : list) {
											moreAudio.setDate(data.getJSONObject(i).getString("date"));
										}
										moreAudios.addAll(list);
									}


									/*for (int i = 0; i < data.size(); i++) {
										List<MoreAudio> list = JSONArray.parseArray(data.getJSONObject(i).getJSONArray("list").toJSONString(), MoreAudio.class);
										MoreAudio moreAudio = new MoreAudio();
										if (i == 0) {
											moreAudio.setDate(data.getJSONObject(i).getString("date"));
											list.add(0, moreAudio);
										}
										if (moreAudios.size() > 0 && moreAudios.get(moreAudios.size() - 1).getDate() != null && list.get(0).getDate() != null) {
											Timber.e("list.get(0).getDate()---->%s", list.get(0).getDate());
											if (moreAudios.get(moreAudios.size() - 1).getDate().equals(list.get(0).getDate())) {
												Timber.e("moreAudios.get(moreAudios.size() - 1).getDate()---->%s", moreAudios.get(moreAudios.size() - 1).getDate());
												list.remove(moreAudio);
											}
										}
										moreAudios.addAll(list);
									}*/
									if (mRootView != null) {
										mRootView.getDataComplete(moreAudios);
										mRootView.getHeaderImageResult(json.getString("url"));
									}
								}

							} else {
								mRootView.getDataComplete(null);
								mRootView.showMessage(jsonObject.getString("errmsg"));
							}
						}
					});
		}
	}


	@Override
	public void onDestroy() {
		super.onDestroy();
		unregisterReceiver();
		clickPosition = -1;
		this.mErrorHandler = null;
		this.mAppManager = null;
		this.mImageLoader = null;
		this.mApplication = null;

	}


	public void registerAudioReceiver() {
		receiver = new MusicInfoReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(GlobalConsts.ACTION_MUSIC_STARTED);
		filter.addAction(GlobalConsts.ACTION_UPDATE_PROGRESS);
		filter.addAction(GlobalConsts.ACTION_STATR_MUSIC);
		filter.addAction(GlobalConsts.ACTION_PAUSE_MUSIC);
		filter.addAction(GlobalConsts.ACTION_LOCAL_MUSIC);
		filter.addAction(GlobalConsts.ACTION_ONLINE_MUSIC);
		filter.addAction(GlobalConsts.ACTION_NEXT_MUSIC);
		filter.addAction(GlobalConsts.ACTION_COMPLETE_MUSIC);
		mApplication.registerReceiver(receiver, filter);

	}


	class MusicInfoReceiver extends BroadcastReceiver {
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Timber.e(action);
			if (action == null || clickPosition == -1) {
				return;
			}
			if (action.equals(GlobalConsts.ACTION_UPDATE_PROGRESS)) {
				int current = intent.getIntExtra("current", 0);
				int total = intent.getIntExtra("total", 0);
				/*mAudioList.get(clickPosition).setCurrentDuration(current);
				mAdapter.notifyItemRangeChanged(clickPosition, 1);*/

				mRootView.upDateAudioProgress(clickPosition, current, total);

			} else if (GlobalConsts.ACTION_LOCAL_MUSIC.equals(action)) {


			} else if (GlobalConsts.ACTION_PAUSE_MUSIC.equals(action)) {
				//音乐暂停播放

			} else if (GlobalConsts.ACTION_STATR_MUSIC.equals(action)) {
				//只有点暂停和播放按钮时

			} else if (GlobalConsts.ACTION_ONLINE_MUSIC.equals(action)) {

			} else if (GlobalConsts.ACTION_NEXT_MUSIC.equals(action)) {

			} else if (GlobalConsts.ACTION_MUSIC_STARTED.equals(action)) {
				//音乐开始播放
				/*mAudioList.get(clickPosition).setType(1);
				mOperatingAnim.cancel();
				mAdapter.notifyDataSetChanged();*/
				mRootView.startMusic(clickPosition);

			} else if (GlobalConsts.ACTION_COMPLETE_MUSIC.equals(action)) {
				//播放完成
				/*mAudioList.get(clickPosition).setType(0);
				mAudioList.get(clickPosition).setCurrentDuration(0);
				mAdapter.notifyDataSetChanged();*/
				mRootView.completeMusic(clickPosition);
			}
		}

	}


	public void unregisterReceiver() {
		try {
			if (receiver != null && mApplication != null) {
				mApplication.unregisterReceiver(receiver);
				receiver = null;
			}
			if (musicBinder != null && clickPosition != -1) {
				musicBinder.pause();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setMusicBinder(PlayService.MusicBinder binder) {
		musicBinder = binder;
	}


}
