package com.zhongyou.meet.mobile.entities;

/**
 * Created by wufan on 2017/7/20.
 */

public class Wechat {

    /**
     * id : 706d61593ca14623b3aad55d446759c6
     * createDate : 2017-07-21 10:22:12
     * updateDate : 2017-07-21 10:22:12
     * delFlag : 0
     * officialAccounts : 9
     * subscribe : 0
     * openid : ofPOO1Jq0Jn9JJbTqG9bQ_wusGLc
     * nickname : 艾伦啊
     * sex : 1
     * headimgurl : http://wx.qlogo.cn/mmhead/nuOMHIm6a9tkPEa2UgKodDmVVu6T1QsKsSTsicvsCJnQ/0
     * city :
     * province :
     * country : China
     * unionid : oNsKkw5hr65Pb-fPCczPXi8tEqX0
     * language : zh_CN
     * userId : e414d731b8284431a0692e39dd11c95d
     * nicknameEmoji : 艾伦啊
     */

    private String id;
    private String createDate;
    private String updateDate;
    private String delFlag;
    private int officialAccounts;
    private int subscribe;
    private String openid;
    private String nickname;
    private int sex;
    private String headimgurl;
    private String city;
    private String province;
    private String country;
    private String unionid;
    private String language;
    private String userId;
    private String nicknameEmoji;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public int getOfficialAccounts() {
        return officialAccounts;
    }

    public void setOfficialAccounts(int officialAccounts) {
        this.officialAccounts = officialAccounts;
    }

    public int getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(int subscribe) {
        this.subscribe = subscribe;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getHeadimgurl() {
        return headimgurl;
    }

    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNicknameEmoji() {
        return nicknameEmoji;
    }

    public void setNicknameEmoji(String nicknameEmoji) {
        this.nicknameEmoji = nicknameEmoji;
    }

    @Override
    public String toString() {
        return "Wechat{" +
                "id='" + id + '\'' +
                ", createDate='" + createDate + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", delFlag='" + delFlag + '\'' +
                ", officialAccounts=" + officialAccounts +
                ", subscribe=" + subscribe +
                ", openid='" + openid + '\'' +
                ", nickname='" + nickname + '\'' +
                ", sex=" + sex +
                ", headimgurl='" + headimgurl + '\'' +
                ", city='" + city + '\'' +
                ", province='" + province + '\'' +
                ", country='" + country + '\'' +
                ", unionid='" + unionid + '\'' +
                ", language='" + language + '\'' +
                ", userId='" + userId + '\'' +
                ", nicknameEmoji='" + nicknameEmoji + '\'' +
                '}';
    }
}
