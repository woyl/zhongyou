package com.zhongyou.meet.mobile.config;

import android.support.v4.content.FileProvider;

public class MyFileProvider extends FileProvider {
}
