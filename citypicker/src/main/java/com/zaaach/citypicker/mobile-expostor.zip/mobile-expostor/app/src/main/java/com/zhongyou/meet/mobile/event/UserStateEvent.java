package com.zhongyou.meet.mobile.event;

/**用户在线状态改变
 * Created by wufan on 2017/7/27.
 */

public class UserStateEvent {

    public UserStateEvent() {
    }




}
