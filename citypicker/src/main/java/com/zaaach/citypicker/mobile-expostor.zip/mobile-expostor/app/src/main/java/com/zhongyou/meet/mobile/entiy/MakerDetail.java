package com.zhongyou.meet.mobile.entiy;

import java.util.List;

/**
 * @author golangdorid@gmail.com
 * @date 2020/4/17 2:27 PM.
 * @
 */
public class MakerDetail {

	/**
	 * subPages : [{"subPageURL":"123456","sort":1,"type":4,"subPageId":"7a35c86e552949959d9c9aecd47ec340"}]
	 * pictureURL : mksbdkjahgsdkjahsdioh
	 * name : 详情页面
	 * isRecord : 1
	 * id : e70333f396314948b87ac3f945cb0276
	 * type : 1
	 * introduceURL : askludhakljsdhkjalhsbd
	 */

	private String pictureURL;
	private String name;
	private int isRecord;
	private String id;
	private int type;
	private String introduceURL;
	private int isSign;
	private List<SubPagesBean> subPages;

	public int getIsSign() {
		return isSign;
	}

	public void setIsSign(int isSign) {
		this.isSign = isSign;
	}

	public String getPictureURL() {
		return pictureURL;
	}

	public void setPictureURL(String pictureURL) {
		this.pictureURL = pictureURL;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIsRecord() {
		return isRecord;
	}

	public void setIsRecord(int isRecord) {
		this.isRecord = isRecord;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getIntroduceURL() {
		return introduceURL;
	}

	public void setIntroduceURL(String introduceURL) {
		this.introduceURL = introduceURL;
	}

	public List<SubPagesBean> getSubPages() {
		return subPages;
	}

	public void setSubPages(List<SubPagesBean> subPages) {
		this.subPages = subPages;
	}

	public static class SubPagesBean {
		/**
		 * subPageURL : 123456
		 * sort : 1
		 * type : 4
		 * subPageId : 7a35c86e552949959d9c9aecd47ec340
		 */

		private String subPageURL;
		private int sort;
		private int type;
		private String subPageId;
		private String name;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSubPageURL() {
			return subPageURL;
		}

		public void setSubPageURL(String subPageURL) {
			this.subPageURL = subPageURL;
		}

		public int getSort() {
			return sort;
		}

		public void setSort(int sort) {
			this.sort = sort;
		}

		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public String getSubPageId() {
			return subPageId;
		}

		public void setSubPageId(String subPageId) {
			this.subPageId = subPageId;
		}
	}
}
