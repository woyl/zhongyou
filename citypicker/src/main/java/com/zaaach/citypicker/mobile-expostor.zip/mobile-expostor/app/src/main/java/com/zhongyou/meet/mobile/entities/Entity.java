package com.zhongyou.meet.mobile.entities;


public interface Entity {

}
