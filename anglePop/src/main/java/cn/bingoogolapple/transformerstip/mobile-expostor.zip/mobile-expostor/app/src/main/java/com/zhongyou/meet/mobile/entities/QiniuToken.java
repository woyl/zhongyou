package com.zhongyou.meet.mobile.entities;

/**
 * Created by wufan on 2017/7/31.
 */

public class QiniuToken {

    /**
     * token : Ts2x89CKN9YTE7-fCFiiTCJYmL4WzCc74ukD0BIS:y4VYEyInO2sR_HYgoFo4NeQWN1I=:eyJzY29wZSI6ImltYWdldGVzdCIsImRlYWRsaW5lIjoxNTAxNDg3NjczfQ==
     */

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
