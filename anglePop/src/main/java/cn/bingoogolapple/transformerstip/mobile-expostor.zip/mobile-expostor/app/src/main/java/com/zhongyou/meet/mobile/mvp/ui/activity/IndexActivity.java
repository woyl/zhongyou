package com.zhongyou.meet.mobile.mvp.ui.activity;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.allen.library.SuperButton;
import com.huawei.agconnect.config.AGConnectServicesConfig;
import com.huawei.hms.aaid.HmsInstanceId;
import com.huawei.hms.common.ApiException;
import com.igexin.sdk.PushManager;
import com.jess.arms.base.BaseActivity;
import com.jess.arms.di.component.AppComponent;
import com.jess.arms.utils.ArmsUtils;
import com.jess.arms.utils.RxBus;
import com.just.agentwebX5.AgentWebX5;
import com.just.agentwebX5.DefaultWebClient;
import com.kongzue.dialog.interfaces.OnDialogButtonClickListener;
import com.kongzue.dialog.util.BaseDialog;
import com.kongzue.dialog.util.DialogSettings;
import com.kongzue.dialog.v3.MessageDialog;
import com.orhanobut.logger.Logger;
import com.tencent.mmkv.MMKV;
import com.xiaomi.mipush.sdk.MiPushClient;
import com.zhongyou.meet.mobile.BuildConfig;
import com.zhongyou.meet.mobile.Constant;
import com.zhongyou.meet.mobile.IM.IMInfoProvider;
import com.zhongyou.meet.mobile.IM.IMManager;
import com.zhongyou.meet.mobile.R;
import com.zhongyou.meet.mobile.config.BuglyUtil;
import com.zhongyou.meet.mobile.core.PlayService;
import com.zhongyou.meet.mobile.di.component.DaggerIndexComponent;
import com.zhongyou.meet.mobile.entiy.MeetingsData;
import com.zhongyou.meet.mobile.mvp.contract.IndexContract;
import com.zhongyou.meet.mobile.mvp.presenter.IndexPresenter;
import com.zhongyou.meet.mobile.mvp.presenter.MakerCourseAudioDetailPresenter;
import com.zhongyou.meet.mobile.mvp.presenter.MakerCourseAudioPresenter;
import com.zhongyou.meet.mobile.mvp.ui.fragment.MakerFragment;
import com.zhongyou.meet.mobile.mvp.ui.fragment.MeetingFragment;
import com.zhongyou.meet.mobile.mvp.ui.fragment.MyFragment;
import com.zhongyou.meet.mobile.persistence.Preferences;
import com.zhongyou.meet.mobile.utils.MMKVHelper;
import com.zhongyou.meet.mobile.utils.Page;
import com.zhongyou.meet.mobile.utils.Sampler;
import com.zhongyou.meet.mobile.utils.SpUtil;
import com.zhongyou.meet.mobile.utils.statistics.ZYAgent;
import com.zhongyou.meet.mobile.view.WebLayout;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import butterknife.BindView;
import cn.jpush.android.api.JPushInterface;
import io.rong.imkit.RongIM;
import io.rong.imlib.model.UserInfo;
import me.jessyan.autosize.AutoSizeCompat;
import me.majiajie.pagerbottomtabstrip.NavigationController;
import me.majiajie.pagerbottomtabstrip.PageNavigationView;
import me.majiajie.pagerbottomtabstrip.item.BaseTabItem;
import me.majiajie.pagerbottomtabstrip.item.NormalItemView;
import me.majiajie.pagerbottomtabstrip.listener.OnTabItemSelectedListener;
import timber.log.Timber;

import static com.jess.arms.utils.Preconditions.checkNotNull;
import static io.rong.imkit.utils.SystemUtils.getCurProcessName;


/**
 * ================================================
 * Description:
 * <p>
 * Created by MVPArmsTemplate on 03/20/2020 14:20
 * <a href="mailto:jess.yan.effort@gmail.com">Contact me</a>
 * <a href="https://github.com/JessYanCoding">Follow me</a>
 * <a href="https://github.com/JessYanCoding/MVPArms">Star me</a>
 * <a href="https://github.com/JessYanCoding/MVPArms/wiki">See me</a>
 * <a href="https://github.com/JessYanCoding/MVPArmsTemplate">模版请保持更新</a>
 * ================================================
 */
@Page(name = "首页")
public class IndexActivity extends BaseActivity<IndexPresenter> implements IndexContract.View {
	@BindView(R.id.pager_bottom_tab)
	PageNavigationView pagerBottomTab;
	private List<Fragment> mFragments;
	private FragmentManager mMamager;
	private Fragment mFragment;
	private long mExitTime;
	private ServiceConnection serviceConn;
	private PlayService.MusicBinder musicBinder;
	private AliansReeiver mAliansReeiver;

	@Override
	public void setupActivityComponent(@NonNull AppComponent appComponent) {
		DaggerIndexComponent //如找不到该类,请编译一下项目
				.builder()
				.appComponent(appComponent)
				.view(this)
				.build()
				.inject(this);

	}

	@Override
	public int initView(@Nullable Bundle savedInstanceState) {
		return R.layout.activity_index; //如果你不需要框架帮你设置 setContentView(id) 需要自行设置,请返回 0
	}

	@Override
	public void initData(@Nullable Bundle savedInstanceState) {
		initFragment();
		initBottomBar();


		if (mPresenter != null) {
			//版本检测
//			mPresenter.versionCheck(BuildConfig.APPLICATION_ID, BuildConfig.VERSION_CODE + "");
			//设备注册
			mPresenter.registerDevices();

			//会议状态更改
			mPresenter.meetingJoinStats();
		}
		initPlayService();

		mPresenter.LoginIM();

		IMInfoProvider infoProvider = new IMInfoProvider();
		infoProvider.init(this);

		UserInfo info = new UserInfo(MMKV.defaultMMKV().decodeString(MMKVHelper.ID), MMKV.defaultMMKV().decodeString(MMKVHelper.USERNICKNAME), Uri.parse(MMKV.defaultMMKV().decodeString(MMKVHelper.PHOTO)));

		RongIM.getInstance().refreshUserInfoCache(info);
		RongIM.getInstance().setCurrentUserInfo(info);
		RongIM.getInstance().setMessageAttachedUserInfo(true);


		Intent intent = getIntent();
		Uri uri = intent.getData();
		if (uri != null) {
			if (uri.getHost().contains("com.hezy.guide.phone")) {
				String code = uri.getQueryParameter("j");
				String meetingId = uri.getQueryParameter("m");
				Timber.e("code---->%s", code);
				Timber.e("meetingId---->%s", meetingId);
				if (mFragments != null) {
					Constant.KEY_meetingID = meetingId;
					Constant.KEY_code = code;
				}

			}


		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			String channelId = "video";
			String channelName = "视频直播";
			int importance = NotificationManager.IMPORTANCE_DEFAULT;
			createNotificationChannel(channelId, channelName, importance);

		}
		//showUpDateDialog();
		DialogSettings.style = DialogSettings.STYLE.STYLE_IOS;
		Logger.e("Build.BRAND:--->" + Build.BRAND);

		if (BuildConfig.DEBUG && Build.BRAND.contains("samsung")) {
			verifyHasFloatViewPermission();
		}
			//腾讯个推
		if (!MMKV.defaultMMKV().decodeBool(Constant.KEY_BIND_ALIAS_TAG, false)) {
			PushManager.getInstance().bindAlias(this, MMKV.defaultMMKV().decodeString(MMKVHelper.ID));
		}
		//极光推送
		if (!MMKV.defaultMMKV().decodeBool(MMKVHelper.KEY_SETALIASSUCCESS, false)) {
			JPushInterface.setAlias(this, 1, MMKV.defaultMMKV().decodeString(MMKVHelper.ID));
		}

		registerBoradCastReceiver();
		checkNotifySetting(MMKV.defaultMMKV().decodeBool(MMKVHelper.KEY_CHECK_NOTIFY, false));


//		new Thread(){
//			@Override
//			public void run() {
//				try {
//					// read from agconnect-services.json
//					// operation in MAIN thread prohibited
//					String appId = AGConnectServicesConfig.fromContext(IndexActivity.this).getString("client/app_id");
//					String token = HmsInstanceId.getInstance(IndexActivity.this).getToken(appId, "HCM");
//					Log.e("HMSTOKEN","HMS TOKEN-->"+token);
//				} catch (ApiException e) {
//					e.printStackTrace();
//				}
//
//			}
//		}.start();
//
//		String regId = MiPushClient.getRegId(getApplicationContext());
//		Logger.e("MIPUSH--->"+regId);

	}

	private void checkNotifySetting(boolean isNeedNotify) {
		NotificationManagerCompat manager = NotificationManagerCompat.from(this);
		// areNotificationsEnabled方法的有效性官方只最低支持到API 19，低于19的仍可调用此方法不过只会返回true，即默认为用户已经开启了通知。
		boolean isOpened = manager.areNotificationsEnabled();

		if (!isOpened && !isNeedNotify) {
			MessageDialog.show(IndexActivity.this, "是否开启通知权限", "没有开启通知权限，可能会错过会议", "开启", "不再提示").setOnOkButtonClickListener(new OnDialogButtonClickListener() {
				@Override
				public boolean onClick(BaseDialog baseDialog, View v) {
					// 根据isOpened结果，判断是否需要提醒用户跳转AppInfo页面，去打开App通知权限
					try {
						Intent intent = new Intent();
						intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
						//这种方案适用于 API 26, 即8.0（含8.0）以上可以用
						intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
						intent.putExtra(Settings.EXTRA_CHANNEL_ID, getApplicationInfo().uid);
						//这种方案适用于 API21——25，即 5.0——7.1 之间的版本可以使用
						intent.putExtra("app_package", getPackageName());
						intent.putExtra("app_uid", getApplicationInfo().uid);
						startActivity(intent);
					} catch (Exception e) {
						e.printStackTrace();
						// 出现异常则跳转到应用设置界面：锤子坚果3——OC105 API25
						Intent intent = new Intent();
						intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
						Uri uri = Uri.fromParts("package", getPackageName(), null);
						intent.setData(uri);
						startActivity(intent);

					}
					return false;
				}
			}).setOnCancelButtonClickListener(new OnDialogButtonClickListener() {
				@Override
				public boolean onClick(BaseDialog baseDialog, View v) {
					MMKV.defaultMMKV().encode(MMKVHelper.KEY_CHECK_NOTIFY, true);
					return false;
				}
			});
		}
	}

	private void registerBoradCastReceiver() {
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction("com.meeting.mobile.bindaliansfail");
		intentFilter.addAction("com.meeting.mobile.opennotifycation");
		intentFilter.addAction("com.meeting.mobile.setaliasfaliled");
		mAliansReeiver = new AliansReeiver();
		LocalBroadcastManager.getInstance(this).registerReceiver(mAliansReeiver, intentFilter);

	}

	private void verifyHasFloatViewPermission() {
		//Android 6.0 以下无需获取权限，可直接展示悬浮窗
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			//判断是否拥有悬浮窗权限，无则跳转悬浮窗权限授权页面
			if (Settings.canDrawOverlays(this)) {

			} else {
				//跳转悬浮窗权限授权页面
				MessageDialog.show(IndexActivity.this, "是否开启视频悬浮窗", "检测到没有开启视频悬浮窗权限 是否开启", "开启", "取消").setOnOkButtonClickListener(new OnDialogButtonClickListener() {
					@Override
					public boolean onClick(BaseDialog baseDialog, View v) {
						startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
						return false;
					}
				});
			}
		}
	}

	@TargetApi(Build.VERSION_CODES.O)
	private void createNotificationChannel(String channelId, String channelName, int importance) {
		NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
		NotificationManager notificationManager = (NotificationManager) getSystemService(
				NOTIFICATION_SERVICE);
		if (notificationManager != null) {
			notificationManager.createNotificationChannel(channel);
		}

	}

	private void initPlayService() {
		//播放服务
		Intent intent = new Intent(getActivity(), PlayService.class);
		serviceConn = new ServiceConnection() {
			//连接异常断开
			public void onServiceDisconnected(ComponentName name) {

			}

			//连接成功
			public void onServiceConnected(ComponentName name, IBinder binder) {
				musicBinder = (PlayService.MusicBinder) binder;
				MakerFragment fragment = (MakerFragment) mFragments.get(0);
				fragment.setMusicBinder(musicBinder);
				MakerCourseAudioPresenter.setMusicBinder(musicBinder);
				MakerCourseAudioDetailActivity.setMusicBinder(musicBinder);
			}
		};

		bindService(intent, serviceConn, Service.BIND_AUTO_CREATE);
	}

	@Override
	public void initFragment() {
		mFragments = new ArrayList<>();
		mFragments.add(new MakerFragment());
		mFragments.add(new MeetingFragment());
//		mFragments.add(new DiscussFragment());
		mFragments.add(new MyFragment());
		mFragment = mFragments.get(0);
		mMamager = getSupportFragmentManager();
		FragmentTransaction transaction = mMamager.beginTransaction();
		transaction.replace(R.id.container, mFragments.get(0));
		transaction.commit();


	}


	@Override
	public void initBottomBar() {
		NavigationController navigationController = pagerBottomTab.custom()
				.addItem(newItem(R.drawable.icon_creater, R.drawable.icon_creater_select, "创客"))
				.addItem(newItem(R.drawable.icon_meeting, R.drawable.icon_meeting_select, "教室"))
//				.addItem(newItem(R.drawable.rzh, R.drawable.rzl, "日志"))
				.addItem(newItem(R.drawable.wdh, R.drawable.my_select, "我的"))
				.build();

		//底部按钮的点击事件监听
		navigationController.addTabItemSelectedListener(new OnTabItemSelectedListener() {
			@Override
			public void onSelected(int index, int old) {

				switchContent(mFragment, index);

			}

			@Override
			public void onRepeat(int index) {
			}
		});
//		navigationController.setSelect(0);
//		navigationController.setMessageNumber(2, 100);
//		navigationController.setHasMessage(3, true);
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	@Override
	public AppCompatActivity getActivity() {
		return this;
	}

	/*因为启动页已经弄了版本检测更新 这个地方没必要了*/
	@Override
	public void showUpDateDialog() {

		Dialog dialog = new Dialog(this, R.style.MyDialog);
		View v = View.inflate(this, R.layout.dialog_update, null);
		dialog.setContentView(v);

		TextView tilte = v.findViewById(R.id.title);
		TextView message = v.findViewById(R.id.content);
		TextView close = v.findViewById(R.id.close);
		TextView update = v.findViewById(R.id.update);
		tilte.setText("更新提示");
		message.setText("1. 修复登陆问题\n2020.03.19");
		close.setText("关闭");
		update.setText("立即更新");
		dialog.show();

		update.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();

			}
		});


	}

	@Override
	public void showAgreementDialog() {

	}

	@Override
	public void LoginImSuccess(boolean b) {
		if (!b) {
			MessageDialog.show(IndexActivity.this, "提示", "登录聊天系统失败", "退出").setOnOkButtonClickListener(new OnDialogButtonClickListener() {
				@Override
				public boolean onClick(BaseDialog baseDialog, View v) {
					killMyself();
					return false;
				}
			}).setCancelable(false);
		}
	}


	//创建一个Item 带文字图表
	private BaseTabItem newItem(int drawable, int checkedDrawable, String text) {
		NormalItemView normalItemView = new NormalItemView(this);
		normalItemView.initialize(drawable, checkedDrawable, text);
		normalItemView.setTextDefaultColor(getResources().getColor(R.color.color_999999));
		normalItemView.setTextCheckedColor(getResources().getColor(R.color.color_4095e8));
		return normalItemView;
	}

	public void switchContent(Fragment from, int position) {
		if (mFragment != mFragments.get(position)) {
			mFragment = mFragments.get(position);
			FragmentTransaction transaction = mMamager.beginTransaction();
			if (!mFragments.get(position).isAdded()) {
				// 隐藏当前的fragment，add下一个到Activity中
				transaction.hide(from).add(R.id.container, mFragments.get(position)).commitAllowingStateLoss();
			} else {
				// 隐藏当前的fragment，显示下一个
				transaction.hide(from).show(mFragments.get(position)).commitAllowingStateLoss();
			}
		}
	}


	@Override
	public void showLoading() {

	}

	@Override
	public void hideLoading() {

	}

	@Override
	protected void onDestroy() {
		mFragments = null;
		mFragment = null;
		mMamager = null;

		try {
			if (serviceConn != null) {
				unbindService(serviceConn);
			}

			if (mAliansReeiver != null) {
				LocalBroadcastManager.getInstance(this).unregisterReceiver(mAliansReeiver);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.onDestroy();
		}
	}

	@Override
	public void showMessage(@NonNull String message) {
		checkNotNull(message);
		ArmsUtils.snackbarText(message);
	}

	@Override
	public void launchActivity(@NonNull Intent intent) {
		checkNotNull(intent);
		ArmsUtils.startActivity(intent);
	}

	@Override
	public void killMyself() {
		finish();
	}


	@Override
	public void onBackPressed() {
		if ((System.currentTimeMillis() - mExitTime) > 2000) {
			Toast.makeText(this, "再按一次退出中幼在线", Toast.LENGTH_SHORT).show();
			mExitTime = System.currentTimeMillis();
		} else {
			quit();
		}
	}

	private void quit() {
		ZYAgent.onEvent(getApplicationContext(), "返回退出应用 连接服务 请求停止");
//		WSService.stopService(this);
		finish();
		System.exit(0);
	}

	@Override
	public Resources getResources() {
		AutoSizeCompat.autoConvertDensityOfGlobal((super.getResources()));
		return super.getResources();
	}

	public class AliansReeiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction() != null) {
				if (intent.getAction().equals("com.meeting.mobile.bindaliansfail")) {
					new Handler().postDelayed((Runnable) () -> {
						if (MMKV.defaultMMKV().decodeBool(Constant.KEY_BIND_ALIAS_TAG, false)) {
							PushManager.getInstance().bindAlias(IndexActivity.this, MMKV.defaultMMKV().decodeString(MMKVHelper.ID));
						}
					}, 60 * 1000);
				}else if (intent.getAction().equals("com.meeting.mobile.opennotifycation")) {
					intent = new Intent(IndexActivity.this, MessageDetailActivity.class);
					startActivity(intent);
				}else if (intent.getAction().equals("com.meeting.mobile.setaliasfaliled")) {
					new Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							JPushInterface.setAlias(IndexActivity.this, 1, MMKV.defaultMMKV().decodeString(MMKVHelper.ID));
						}
					}, 60 * 1000);

				}
			}
		}
	}
}
