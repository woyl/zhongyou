package com.zhongyou.meet.mobile.entiy;

public class Seriser {

    /**
     * clickCount : 0
     * createDate : 2020-09-23 14:44:28
     * delFlag : 0
     * id : 4cfb43107f654e449c7a464eb7e477f5
     * isAuth : 1
     * isSign : 0
     * isSignUp : 1
     * isUp : 0
     * name : 托尔斯泰
     * pageId : 294a8bc9ef424160af4ab3465cf456bb
     * pageName : 0-9岁儿童的35个成长关键期
     * pictureURL : https://syimage.zhongyouie.com//1600843490941timg (8).jpg
     * singUpNum : 0
     * type : 1
     * typeId : 0d001e32c0a14c2a8211e0ce0603cebe
     * typeName : 幼小衔接
     * upTime : 2020-09-23 14:44:18
     * updateDate : 2020-09-23 14:44:48
     */

    private int clickCount;
    private String createDate;
    private String delFlag;
    private String id;
    private int isAuth;
    private int isSign;
    private int isSignUp;
    private int isUp;
    private String name;
    private String pageId;
    private String pageName;
    private String pictureURL;
    private int singUpNum;
    private int type;
    private String typeId;
    private String typeName;
    private String upTime;
    private String updateDate;

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(int isAuth) {
        this.isAuth = isAuth;
    }

    public int getIsSign() {
        return isSign;
    }

    public void setIsSign(int isSign) {
        this.isSign = isSign;
    }

    public int getIsSignUp() {
        return isSignUp;
    }

    public void setIsSignUp(int isSignUp) {
        this.isSignUp = isSignUp;
    }

    public int getIsUp() {
        return isUp;
    }

    public void setIsUp(int isUp) {
        this.isUp = isUp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPageId() {
        return pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getPictureURL() {
        return pictureURL;
    }

    public void setPictureURL(String pictureURL) {
        this.pictureURL = pictureURL;
    }

    public int getSingUpNum() {
        return singUpNum;
    }

    public void setSingUpNum(int singUpNum) {
        this.singUpNum = singUpNum;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getUpTime() {
        return upTime;
    }

    public void setUpTime(String upTime) {
        this.upTime = upTime;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }
}
