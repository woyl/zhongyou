package com.zhongyou.meet.mobile.event;

/**用户挂断通知
 * Created by wufan on 2017/7/27.
 */

public class HangOnEvent {
}
