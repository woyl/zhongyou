package com.zhongyou.meet.mobile.view;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * Created by wufan on 2017/7/26.
 */

public class MyTextWatcher implements TextWatcher {
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
