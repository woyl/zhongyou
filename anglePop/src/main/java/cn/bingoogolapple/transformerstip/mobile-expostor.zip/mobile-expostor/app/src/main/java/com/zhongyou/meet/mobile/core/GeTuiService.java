package com.zhongyou.meet.mobile.core;

import com.igexin.sdk.PushService;

/**
 * @author golangdorid@gmail.com
 * @date 2020/9/11 1:59 PM.
 * @
 */
public class GeTuiService extends PushService {
}
