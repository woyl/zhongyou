package io.agora.openlive.model;

import io.agora.rtc.Constants;

public class ConstantApp {
	public static final String APP_BUILD_DATE = "today";

	public static final int BASE_VALUE_PERMISSION = 0X0001;
	public static final int PERMISSION_REQ_ID_RECORD_AUDIO = BASE_VALUE_PERMISSION + 1;
	public static final int PERMISSION_REQ_ID_CAMERA = BASE_VALUE_PERMISSION + 2;
	public static final int PERMISSION_REQ_ID_WRITE_EXTERNAL_STORAGE = BASE_VALUE_PERMISSION + 3;

	public static final int MAX_PEER_COUNT = 3;

	public static int[] VIDEO_PROFILES = new int[]{
			Constants.VIDEO_PROFILE_180P,//320*180
			Constants.VIDEO_PROFILE_480P,// 640 × 480
			Constants.VIDEO_PROFILE_720P,//960*720
			Constants.VIDEO_PROFILE_180P,//1920 × 1080
			Constants.VIDEO_PROFILE_480P,//640 x 480
			Constants.VIDEO_PROFILE_720P};

	public static final int DEFAULT_PROFILE_IDX = 1; // default use 480P

	public static class PrefManager {
		public static final String PREF_PROPERTY_PROFILE_IDX = "pref_profile_index";
		public static final String PREF_PROPERTY_UID = "pOCXx_uid";
	}

	public static final String ACTION_KEY_CROLE = "C_Role";
	public static final String ACTION_KEY_ROOM_NAME = "ecHANEL";
}
