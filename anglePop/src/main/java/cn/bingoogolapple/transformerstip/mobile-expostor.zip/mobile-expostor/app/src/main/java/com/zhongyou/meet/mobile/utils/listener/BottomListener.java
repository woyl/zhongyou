package com.zhongyou.meet.mobile.utils.listener;

/**
 * @author Dongce
 * create time: 2018/11/29
 */
public interface BottomListener {
    /**
     * 滑动到底部时回调
     */
    void onScrollToBottom();
}
