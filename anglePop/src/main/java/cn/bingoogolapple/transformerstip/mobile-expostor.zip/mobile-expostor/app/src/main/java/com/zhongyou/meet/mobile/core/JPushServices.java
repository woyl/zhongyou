package com.zhongyou.meet.mobile.core;

import cn.jpush.android.service.JCommonService;

/**
 * @author golangdorid@gmail.com
 * @date 2020/7/8 4:58 PM.
 * @
 */
public class JPushServices extends JCommonService {
}
