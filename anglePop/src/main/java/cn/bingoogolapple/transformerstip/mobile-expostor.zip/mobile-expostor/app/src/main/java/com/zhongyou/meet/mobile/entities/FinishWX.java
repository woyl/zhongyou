package com.zhongyou.meet.mobile.entities;

/**
 * Created by wufan on 2017/7/31.
 */

public class FinishWX {
}
