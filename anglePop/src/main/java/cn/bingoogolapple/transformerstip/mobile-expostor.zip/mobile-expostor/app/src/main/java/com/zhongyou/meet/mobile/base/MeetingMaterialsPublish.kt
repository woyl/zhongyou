package com.zhongyou.meet.mobile.base

data class MeetingMaterialsPublish(
    val createDate: String,
    val delFlag: String,
    val id: String,
    val materialsId: String,
    val name: String,
    val priority: Int,
    val type: String,
    val updateDate: String,
    val url: String
)