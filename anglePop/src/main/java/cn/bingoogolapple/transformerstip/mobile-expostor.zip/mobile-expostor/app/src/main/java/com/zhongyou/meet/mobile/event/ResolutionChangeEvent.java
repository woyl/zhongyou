package com.zhongyou.meet.mobile.event;

/**
 * Created by whatisjava on 17-9-11.
 */

public class ResolutionChangeEvent {

    private int resolution;

    public int getResolution() {
        return resolution;
    }

    public void setResolution(int resolution) {
        this.resolution = resolution;
    }
}
